#!/bin/sh
java -jar SnapTwitter.jar